/* PERSONAGENS E AVATARES: ilustrações vetoriais (SVG) desenhadas do zero para este projeto, em estilo
   cartoon simples. Não usam imagens, cenas ou arte oficiais. O "humor" muda olhos, sobrancelhas e boca. */
'use strict';

const PERSONAGENS = {
  fred: { nome: 'Fred' }, daphne: { nome: 'Daphne' }, velma: { nome: 'Velma' }, salsicha: { nome: 'Salsicha' },
  scooby: { nome: 'Scooby' }, silas: { nome: 'Silas Crane' }, vilao: { nome: 'Fantasma' }
};

const Avatar = (() => {
  const boca = (d, extra) => `<path d="${d}" stroke="#5a2a2a" stroke-width="2.4" fill="none" stroke-linecap="round" ${extra || ''}/>`;
  const HUMORES = {   // l/r: altura das sobrancelhas, t: inclinação (positivo = bravo), o: tamanho dos olhos
    neutro:    { l: 0,  r: 0,  t: 0,  o: 3.2, boca: boca('M43 61 Q50 64 57 61') },
    feliz:     { l: -2, r: -2, t: -1, o: 3.2, boca: '<path d="M39 57 Q50 72 61 57Z" fill="#7b2b2b"/>' },
    assustado: { l: -5, r: -5, t: -4, o: 4.8, boca: '<ellipse cx="50" cy="63" rx="4" ry="5.5" fill="#5a2a2a"/>' },
    surpreso:  { l: -6, r: -6, t: 0,  o: 4.4, boca: '<ellipse cx="50" cy="62" rx="3.4" ry="4.4" fill="#5a2a2a"/>' },
    pensativo: { l: -4, r: 0,  t: 0,  o: 3.2, boca: boca('M43 62 Q50 59 58 63') },
    bravo:     { l: 0,  r: 0,  t: 4,  o: 3.2, boca: boca('M42 64 Q50 58 58 64') }
  };
  const COR = {
    fred:     { pele: '#f2cfa5', cabelo: '#d9b45a', roupa: '#2a8f8f' },
    daphne:   { pele: '#f6d3b3', cabelo: '#a63a2a', roupa: '#a24bb5' },
    velma:    { pele: '#e8bd94', cabelo: '#4a2e22', roupa: '#d08a1e' },
    salsicha: { pele: '#f1c9a0', cabelo: '#7a5230', roupa: '#6f8f3a' },
    silas:    { pele: '#e9c3a0', cabelo: '#8a8a92', roupa: '#2b5fa8' }
  };
  const HAIR = {   // cabelo na frente do rosto
    fred: 'M25 44 Q24 19 50 19 Q76 19 75 44 Q66 31 50 31 Q34 31 25 44Z',
    daphne: 'M25 42 Q50 12 75 42 Q62 28 50 31 Q38 28 25 42Z',
    velma: 'M25 44 Q30 20 50 20 Q70 20 75 44 Q62 32 50 33 Q38 32 25 44Z',
    salsicha: 'M25 42 Q26 18 50 19 Q74 18 75 42 Q64 30 50 32 Q36 30 25 42Z M44 19 Q50 8 58 19Z',
    silas: 'M25 42 Q26 20 50 20 Q74 20 75 42 Q62 34 50 35 Q38 34 25 42Z'
  };
  const BACK = {   // cabelo atrás da cabeça
    daphne: 'M22 46 Q18 18 50 17 Q82 18 78 46 L80 82 L66 70 L34 70 L20 82Z',
    velma: 'M22 52 Q20 17 50 17 Q80 17 78 52 L72 58 L28 58Z'
  };
  function rosto(h, cx1, cx2, cy) {
    const H = HUMORES[h] || HUMORES.neutro;
    const sobr = (a, b, c, d) => `<line x1="${a}" y1="${b}" x2="${c}" y2="${d}" stroke="#2a1a14" stroke-width="2.6" stroke-linecap="round"/>`;
    const olho = x => `<ellipse class="olho" cx="${x}" cy="${cy}" rx="${H.o * 0.8}" ry="${H.o}" fill="#222"/>`;
    return { H, sobrancelhas: sobr(cx1 - 7, cy - 9 + H.l, cx1 + 6, cy - 9 + H.l + H.t) + sobr(cx2 - 6, cy - 9 + H.r + H.t, cx2 + 7, cy - 9 + H.r), olhos: olho(cx1) + olho(cx2) };
  }
  function humano(q, h) {
    const c = COR[q], f = rosto(h, 40, 60, 46);
    const extra = {
      fred: '<path d="M42 70 L50 80 L58 70Z" fill="#fff"/>',
      daphne: '<path d="M26 37 Q50 18 74 37" stroke="#c07ce0" stroke-width="5" fill="none"/>',
      velma: '<circle cx="40" cy="46" r="9" fill="#fff" fill-opacity=".35" stroke="#222" stroke-width="2.2"/><circle cx="60" cy="46" r="9" fill="#fff" fill-opacity=".35" stroke="#222" stroke-width="2.2"/><line x1="49" y1="46" x2="51" y2="46" stroke="#222" stroke-width="2"/>',
      salsicha: `<path d="M44 67 Q50 77 56 67Z" fill="${c.cabelo}"/>`,
      silas: '<circle cx="66" cy="55" r="3.2" fill="#3da5ff"/><path d="M33 56 Q36 58 39 56" stroke="#b08a6a" fill="none"/>'
    }[q];
    return `<path d="M12 100 Q14 74 50 72 Q86 74 88 100Z" fill="${c.roupa}"/><rect x="44" y="64" width="12" height="12" fill="${c.pele}"/>`
      + (BACK[q] ? `<path d="${BACK[q]}" fill="${c.cabelo}"/>` : '')
      + `<circle cx="50" cy="46" r="25" fill="${c.pele}"/><path d="${HAIR[q]}" fill="${c.cabelo}"/>`
      + f.olhos + (q === 'velma' ? '' : '') + extra + f.sobrancelhas + f.H.boca;
  }
  function cachorro(h) {
    const f = rosto(h, 39, 61, 44), feliz = h === 'feliz';
    return '<path d="M14 100 Q16 78 50 76 Q84 78 86 100Z" fill="#8c5d2e"/>'
      + '<rect x="30" y="74" width="40" height="8" rx="4" fill="#d33a3a"/><circle cx="50" cy="85" r="3.4" fill="#f2c94c"/>'
      + '<path d="M27 38 Q8 38 10 68 Q24 66 32 52Z" fill="#6b4220"/><path d="M73 38 Q92 38 90 68 Q76 66 68 52Z" fill="#6b4220"/>'
      + '<ellipse cx="50" cy="50" rx="25" ry="24" fill="#a9743f"/><circle cx="36" cy="33" r="4" fill="#6b4220"/>'
      + '<ellipse cx="50" cy="62" rx="15" ry="11" fill="#e0b57a"/><ellipse cx="50" cy="56" rx="5.5" ry="3.8" fill="#222"/>'
      + f.olhos + f.sobrancelhas
      + `<path d="M50 60 L50 64 M43 66 Q50 ${feliz ? 73 : 68} 57 66" stroke="#4a2a14" stroke-width="2" fill="none" stroke-linecap="round"/>`
      + (feliz ? '<path d="M45 68 Q50 82 55 68Z" fill="#e0607a"/>' : '');
  }
  function fantasma(h) {
    const big = h === 'assustado' || h === 'surpreso';
    return '<path d="M18 92 L18 42 Q18 10 50 10 Q82 10 82 42 L82 92 L71 82 L60 92 L50 82 L40 92 L29 82Z" fill="#fff" fill-opacity=".93"/>'
      + '<ellipse cx="37" cy="42" rx="5" ry="8" fill="#1a1030"/><ellipse cx="63" cy="42" rx="5" ry="8" fill="#1a1030"/>'
      + `<ellipse cx="50" cy="63" rx="${big ? 9 : 7}" ry="${big ? 11 : 9}" fill="#1a1030"/>`;
  }
  /* Devolve o SVG (texto) do personagem com o humor pedido. */
  function svg(q, humor) {
    const corpo = q === 'scooby' ? cachorro(humor) : q === 'vilao' ? fantasma(humor) : humano(COR[q] ? q : 'fred', humor);
    const nome = (PERSONAGENS[q] || { nome: q }).nome;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" role="img" aria-label="${nome}"${q === 'vilao' ? ' class="fantasma-svg"' : ''}>${corpo}</svg>`;
  }
  return { svg };
})();
