/* MOTOR DO JOGO: telas, cutscenes, níveis, missões, recompensas, progresso e restauração.
   O banco da investigação (Banco.db()) é único: o que o jogador faz numa missão vale para as seguintes. */
'use strict';

const CHAVE = 'scoobySqlProgresso2';
const novoEstado = () => ({ feitos: {}, vistas: {}, backup: false });
let estado = carregar();      // { feitos: {idMissao: pontos}, vistas: {cena: true}, backup: bool }
let atual = null;             // missão aberta: { id, m, erros, dica, rev, snap, iniciais, clone }
let cena = null, aoConfirmar = null;

const $ = s => document.querySelector(s);
const M = id => MISSOES[id - 1];
function carregar() { try { return Object.assign(novoEstado(), JSON.parse(localStorage.getItem(CHAVE)) || {}); } catch (e) { return novoEstado(); } }
function salvar() { try { localStorage.setItem(CHAVE, JSON.stringify(estado)); } catch (e) {} }
const total = () => Object.values(estado.feitos).reduce((a, b) => a + b, 0);
const dbAtual = () => atual.rev ? atual.clone : Banco.db();

/* ---------- Telas ---------- */
function mostrar(nome) {
  document.querySelectorAll('.tela').forEach(t => t.classList.remove('ativa'));
  $('#tela-' + nome).classList.add('ativa'); window.scrollTo(0, 0);
  const c = $('#cortina'); c.className = 'cortina'; void c.offsetWidth; c.className = 'cortina rodar';   // transição: sai do preto
}
function irMapa() { $('#modal').hidden = true; desenharMapa(); mostrar('mapa'); }

/* ---------- Cutscenes: abertura animada, texto digitado, atores em cena e transições ----------
   Avançar: clique no palco, botão Próximo, Enter, Espaço ou seta. O primeiro toque completa o texto.
   Pular: botão "Pular cena" ou Esc. */
const VELOCIDADE = 18;   // ms por letra
function tocarCena(nome, depois, vars) {
  const c = CENAS[nome];
  cena = { nome, c, falas: c.falas, i: -1, depois, vars: Object.assign({ nome: 'Silas Crane', n: 6 }, vars), recentes: [], timer: null, fase: 'fala', digitando: false };
  $('#cena-palco').className = 'cena-palco cen-' + c.cenario;
  $('#cena-atores').innerHTML = '';
  mostrar('cena');
  if (c.abertura) { cena.fase = 'abertura'; cena.ab = 0; $('#cena-abertura').hidden = false; $('#cena-balao').classList.add('oculto'); cartao(); }
  else avancar();
}
function cenaUmaVez(nome, depois, vars) { estado.vistas[nome] ? depois() : tocarCena(nome, depois, vars); }
function cartao() {
  const e = $('#cena-abertura-texto'); e.textContent = cena.c.abertura[cena.ab]; e.className = ''; void e.offsetWidth; e.className = 'surge';
  cena.timer = setTimeout(() => { if (++cena.ab < cena.c.abertura.length) cartao(); else fimAbertura(); }, 1700);
}
function fimAbertura() {
  clearInterval(cena.timer); cena.fase = 'fala';
  $('#cena-abertura').hidden = true; $('#cena-balao').classList.remove('oculto'); avancar();
}
function proxFala() {
  if (!cena) return;
  if (cena.fase === 'abertura') return fimAbertura();
  if (cena.digitando) return completar();
  avancar();
}
function avancar() {
  if (++cena.i >= cena.falas.length) return fimCena();
  const f = cena.falas[cena.i];
  cena.recentes = [f.quem].concat(cena.recentes.filter(q => q !== f.quem)).slice(0, 3);
  const box = $('#cena-atores');
  box.innerHTML = cena.recentes.slice().reverse().map(q =>
    `<div class="ator ${q === f.quem ? 'fala' : 'quieto'}">${Avatar.svg(q, q === f.quem ? (f.humor || 'neutro') : 'neutro')}</div>`).join('');
  if (f.efeito) { const p = $('#cena-palco'); p.classList.remove('flash'); void p.offsetWidth; p.classList.add('flash'); }
  $('#cena-nome').textContent = PERSONAGENS[f.quem].nome;
  cena.texto = f.fala.replace(/\{(\w+)\}/g, (m, k) => cena.vars[k] !== undefined ? cena.vars[k] : m);
  $('#cena-progresso').textContent = (cena.i + 1) + ' / ' + cena.falas.length;
  $('#cena-prox').textContent = cena.i === cena.falas.length - 1 ? 'Continuar ▶' : 'Próximo ▶';
  let k = 0; cena.digitando = true; $('#cena-texto').textContent = '';
  clearInterval(cena.timer);
  cena.timer = setInterval(() => { $('#cena-texto').textContent = cena.texto.slice(0, ++k); if (k >= cena.texto.length) completar(); }, VELOCIDADE);
}
function completar() { clearInterval(cena.timer); cena.digitando = false; $('#cena-texto').textContent = cena.texto; }
function fimCena() {
  if (!cena) return;
  clearInterval(cena.timer);
  estado.vistas[cena.nome] = true; salvar();
  const depois = cena.depois; cena = null; depois();
}

/* ---------- Personagem acompanhando a missão: fala de abertura e reações ---------- */
let ultimaReacao = {};
function falar(quem, texto, humor) {
  $('#mentor-av').innerHTML = Avatar.svg(quem, humor || 'neutro');
  $('#mentor-nome').textContent = PERSONAGENS[quem].nome; $('#mentor-fala').textContent = texto;
  const b = $('#mentor'); b.classList.remove('fala'); void b.offsetWidth; b.classList.add('fala');
}
/* Sorteia uma reação do tipo (ok, erro, incompleto, bloqueio, ajuda, dica, desfazer) sem repetir a anterior.
   Com "exceto", só devolve a reação (não mexe no painel do personagem). */
function reagir(tipo, exceto) {
  const todas = REACOES[tipo], outras = todas.filter(r => r.quem !== exceto), lista = outras.length ? outras : todas;
  let r; do { r = lista[Math.floor(Math.random() * lista.length)]; } while (lista.length > 1 && r === ultimaReacao[tipo]);
  ultimaReacao[tipo] = r;
  if (!exceto) falar(r.quem, r.fala, r.humor);
  return r;
}

/* ---------- Mapa: missões só liberam em sequência, então cada nível exige o anterior completo ---------- */
const liberada = id => id === 1 || (id - 1) in estado.feitos;
function desenharMapa() {
  $('#mapa-pontos').textContent = total();
  const caixa = $('#mapa-fases'); caixa.innerHTML = '';
  NIVEIS.forEach((nv, n) => {
    const feitas = nv.missoes.filter(id => id in estado.feitos).length;
    const bloqueado = !liberada(nv.missoes[0]);
    const card = document.createElement('div'); card.className = 'card-fase';
    card.innerHTML = `<h3>${nv.icone} Nível ${n + 1}: ${esc(nv.nome)}</h3><p>${esc(nv.episodio)} · ${feitas}/${nv.missoes.length} missões${bloqueado ? ' · 🔒 conclua o nível anterior' : ''}</p>`;
    const linha = document.createElement('div'); linha.className = 'desafios';
    nv.missoes.forEach(id => {
      const feito = id in estado.feitos, livre = liberada(id), b = document.createElement('button');
      b.className = 'btn-desafio' + (feito ? ' feito' : '') + (livre ? '' : ' trancado');
      b.disabled = !livre; b.title = M(id).titulo;
      b.textContent = feito ? `✔ ${id}` : livre ? `${id}` : `🔒 ${id}`;
      b.onclick = () => abrirMissao(id);
      linha.appendChild(b);
    });
    card.appendChild(linha); caixa.appendChild(card);
  });
}
function desenharCaderno() {
  const itens = MISSOES.filter(m => m.id in estado.feitos);
  $('#caderno-lista').innerHTML = itens.length
    ? itens.map(m => `<div class="item-caderno"><span class="icone">${m.premio.icone}</span><div><b>${esc(m.premio.nome)}</b><br>${esc(m.premio.texto)}<br><small>Missão ${m.id} · ${estado.feitos[m.id]} pts</small></div></div>`).join('')
    : '<p>Ainda não há evidências. Cumpra missões para ganhar recompensas!</p>';
}

/* ---------- Missões ---------- */
function abrirMissao(id) {
  if (!Banco.pronto()) return alert('O banco de dados ainda não carregou. Verifique a internet e recarregue a página.');
  cenaUmaVez(NIVEIS[M(id).nivel - 1].cenaInicio, () => iniciar(id));
}
function iniciar(id) {
  const m = M(id), rev = id in estado.feitos;
  if (atual && atual.clone) atual.clone.close();
  atual = { id, m, erros: 0, dica: false, rev };
  if (rev) { atual.clone = Banco.clonar(Banco.db()); atual.iniciais = Banco.nomes(atual.clone); }
  else { atual.snap = Banco.exportar(Banco.db()); atual.iniciais = Banco.nomes(Banco.db()); }   // ponto de restauração da missão
  $('#d-fase').textContent = `${NIVEIS[m.nivel - 1].icone} Nível ${m.nivel} · Missão ${id}/19`;
  $('#d-titulo').textContent = m.titulo; $('#d-historia').textContent = m.situacao;
  $('#d-objetivo').textContent = m.objetivo; $('#d-conceito').textContent = m.conceito;
  $('#d-dica').hidden = true; $('#sql').value = ''; $('#resultado').innerHTML = ''; $('#painel-tabelas').hidden = true;
  $('#d-pontos').textContent = total();
  msg(rev ? '🔁 Missão já concluída: aqui você treina numa cópia, sem alterar a investigação.' : '', 'info');
  falar(m.guia, ABERTURAS[id], 'neutro');
  mostrar('desafio'); $('#sql').focus();
}
function msg(t, tipo) { const e = $('#mensagem'); e.textContent = t; e.className = 'mensagem ' + tipo; }
function atualizarPainel() { if (!$('#painel-tabelas').hidden) $('#painel-tabelas').innerHTML = Banco.tabelasHTML(dbAtual()); }

/* Executar: roda no banco real e a missão é conferida automaticamente pelos efeitos produzidos. */
function executar() {
  const sql = $('#sql').value.trim(), m = atual.m;
  if (!sql) return msg('Digite um comando SQL primeiro.', 'info');
  const d = dbAtual(), r = Banco.executar(d, sql, atual.iniciais, m.tipo === 'consulta');
  $('#resultado').innerHTML = '';
  if (r.erro) { reagir(r.bloqueado ? 'bloqueio' : 'erro'); return msg('❌ ' + r.erro, 'erro'); }
  $('#resultado').innerHTML = r.tabelas.map(Banco.tabelaHTML).join('');
  atualizarPainel();
  if (atual.rev) return msg('✔ Executado na cópia de treino.', 'info');
  const v = Banco.validar(m, { db: d, snap: atual.snap, iniciais: atual.iniciais, cache: atual,
    resultado: r.tabelas.length ? r.tabelas[r.tabelas.length - 1] : null });
  if (v.ok) return concluir();
  atual.erros++;
  const rx = reagir(atual.erros >= 3 ? 'ajuda' : 'incompleto');
  msg(`${PERSONAGENS[rx.quem].nome}: ${v.motivo}`, 'info');
}
function concluir() {
  const { id, m } = atual, nv = NIVEIS[m.nivel - 1];
  const pts = Math.max(30, 100 - 10 * atual.erros - (atual.dica ? 20 : 0));
  estado.feitos[id] = pts;
  let extra = '';
  if (id === 5 && !estado.backup) { estado.backup = Banco.backup(); extra = estado.backup ? '📦 Backup do museu restaurado no banco!' : '⚠ Não foi possível restaurar o backup. Use "Restaurar investigação".'; }
  salvar(); Banco.salvar();                                  // progresso e estado real do banco
  $('#d-pontos').textContent = total();
  const ultima = nv.missoes[nv.missoes.length - 1] === id;
  $('#modal-titulo').textContent = '🎉 Missão cumprida!';
  const ro = reagir('ok', m.guia), linha = (q, h, txt) => `<div class="fala-linha"><span class="mini-avatar">${Avatar.svg(q, h)}</span><span><b>${PERSONAGENS[q].nome}:</b> ${esc(txt)}</span></div>`;
  $('#modal-fala').innerHTML = linha(m.guia, 'feliz', m.sucesso) + linha(ro.quem, ro.humor, ro.fala);
  $('#modal-texto').textContent = `+${pts} pontos (total: ${total()}). ${extra}`;
  $('#modal-premio').innerHTML = `<span class="icone">${m.premio.icone}</span><div><b>Recompensa: ${esc(m.premio.nome)}</b><br>${esc(m.premio.texto)}</div>`;
  $('#modal-ok').textContent = !ultima ? 'Próxima missão ▶' : id === 19 ? 'Revelar o fantasma ▶' : 'Concluir nível ▶';
  aoConfirmar = () => {
    $('#modal').hidden = true;
    if (!ultima) return iniciar(id + 1);
    cenaUmaVez(nv.cenaFim, () => id === 19 ? cenaUmaVez('final', telaFinal, varsFinal()) : irMapa());
  };
  $('#modal').hidden = false;
}
function dica() { atual.dica = true; reagir('dica'); $('#d-dica').textContent = '💡 ' + atual.m.dica; $('#d-dica').hidden = false; }
function tabelas() {
  const p = $('#painel-tabelas');
  if (!p.hidden) { p.hidden = true; return; }
  p.innerHTML = Banco.tabelasHTML(dbAtual()); p.hidden = false;
}
function desfazer() {
  if (atual.rev) { atual.clone.close(); atual.clone = Banco.clonar(Banco.db()); }
  else Banco.restaurar(atual.snap);
  $('#resultado').innerHTML = ''; atualizarPainel(); reagir('desfazer');
  msg('↩ Missão desfeita: o banco voltou ao estado do início desta missão.', 'info');
}

/* ---------- Final, reinício e menu ---------- */
function varsFinal() {   // o nome revelado vem da view criada pelo jogador na missão 19
  try { const r = Banco.db().exec('SELECT * FROM dossie_fantasma')[0].values.slice().sort((a, b) => b[1] - a[1]); return { nome: r[0][0], n: r[0][1] }; }
  catch (e) { return {}; }
}
function telaFinal() {
  $('#f-equipe').innerHTML = ['fred', 'daphne', 'velma', 'salsicha', 'scooby'].map(q => `<div>${Avatar.svg(q, 'feliz')}</div>`).join('');
  const p = total();
  $('#f-pontos').textContent = p;
  $('#f-rank').textContent = p >= 1600 ? 'Detetive lendário de SQL! 🕵️' : p >= 1100 ? 'Ótimo detetive! 🔦' : 'Caso resolvido! Refaça missões para ganhar mais pontos. 💪';
  let dossie = '';
  try {
    const r = Banco.db().exec('SELECT * FROM dossie_fantasma')[0];
    if (r) dossie = '<h3>🕵️ Dossiê do Fantasma</h3>' + Banco.tabelaHTML({ columns: r.columns, values: r.values.slice().sort((a, b) => b[1] - a[1]) });
  } catch (e) {}
  $('#f-dossie').innerHTML = dossie; mostrar('final');
}
function zerar() {
  if (Object.keys(estado.feitos).length && !confirm('Isso apaga todo o progresso e restaura o banco ao estado inicial. Continuar?')) return false;
  Banco.reiniciar(); estado = novoEstado(); salvar(); return true;
}
function novo() { if (zerar()) tocarCena('intro', irMapa); }
function restaurar() { if (zerar()) irMapa(); }
function continuar() { cenaUmaVez('intro', irMapa); }

const ACOES = {
  novo, continuar, restaurar, reiniciar: novo, executar, dica, tabelas, desfazer,
  ajuda: () => mostrar('ajuda'),
  menu: () => { $('#modal').hidden = true; mostrar('menu'); },
  mapa: irMapa, modalmapa: irMapa,
  caderno: () => { desenharCaderno(); mostrar('caderno'); },
  limpar: () => { $('#sql').value = ''; $('#sql').focus(); },
  proxfala: proxFala, pular: fimCena,
  modalok: () => aoConfirmar && aoConfirmar()
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-acao]');
  if (b && ACOES[b.dataset.acao]) ACOES[b.dataset.acao]();
});
document.addEventListener('keydown', e => {
  if (!cena || (e.target && e.target.tagName === 'BUTTON')) return;
  if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowRight') { e.preventDefault(); proxFala(); }
  else if (e.key === 'Escape') fimCena();
});
$('#menu-equipe').innerHTML = ['fred', 'daphne', 'velma', 'salsicha', 'scooby'].map(q => `<div>${Avatar.svg(q, 'feliz')}</div>`).join('');
$('#sql').addEventListener('keydown', e => { if (e.ctrlKey && e.key === 'Enter') executar(); });

Banco.iniciar()
  .then(() => { $('#status-sql').textContent = '✔ Banco de dados SQLite pronto.'; })
  .catch(() => { $('#status-sql').textContent = '⚠ Não foi possível iniciar o SQLite (sql.js). Verifique a internet e recarregue.'; });
