/* NARRATIVA: cutscenes, falas de abertura das missões e reações a acertos e erros.
   Todos os textos são originais. Nas falas, {nome} e {n} são preenchidos com o resultado real do dossiê.
   Campos opcionais de cada fala: humor (expressão do personagem) e efeito ('flash'). */
'use strict';

const CENAS = {
  intro: { cenario: 'museu', abertura: ['Museu Blackwood', 'Meia-noite. As luzes falham.', 'Um banco de dados apagado. Um "fantasma" à solta.'],
    falas: [
      { quem: 'fred', fala: 'Alguém apagou o banco de dados do museu e culpou um fantasma. Vamos provar o contrário.' },
      { quem: 'velma', humor: 'pensativo', fala: 'Fantasmas não digitam comandos. Os dados guardam a verdade, se soubermos perguntar.' },
      { quem: 'daphne', humor: 'feliz', fala: 'Chamamos um especialista em SQL. Você é o nosso detetive de bancos de dados!' },
      { quem: 'salsicha', humor: 'assustado', fala: 'SQL? O meu SELECT favorito é "SELECT * FROM geladeira". Serve?' },
      { quem: 'scooby', humor: 'feliz', fala: 'Au-au! (Tradução do Salsicha: ele topa, se houver lanche no final.)' },
      { quem: 'fred', fala: 'Combinado. Primeiro, o laboratório: foi lá que os dados sumiram.' }] },
  n1: { cenario: 'lab', abertura: ['Episódio 1', 'Reconstrução do laboratório'],
    falas: [
      { quem: 'daphne', humor: 'surpreso', fala: 'O laboratório está de cabeça para baixo. O banco de dados também.' },
      { quem: 'velma', fala: 'Vamos entender o SGBD, escolher os tipos de dados e recriar as tabelas com chaves.' },
      { quem: 'salsicha', humor: 'feliz', fala: 'Chaves? Eu só achei uma de fenda.' }] },
  n1fim: { cenario: 'lab',
    falas: [
      { quem: 'velma', humor: 'feliz', fala: 'PRIMARY KEY e FOREIGN KEY funcionando. E o backup do museu voltou!' },
      { quem: 'fred', fala: 'Com os registros de volta, agora dá para investigar de verdade.' },
      { quem: 'scooby', humor: 'surpreso', fala: 'Au! (Ele disse: arquivos à vista!)' }] },
  n2: { cenario: 'arquivo', abertura: ['Episódio 2', 'Recuperação dos arquivos'],
    falas: [
      { quem: 'fred', fala: 'Os documentos mais valiosos do museu sumiram. Vamos consultar os registros.' },
      { quem: 'daphne', fala: 'Filtrar, ordenar e corrigir dados. E UPDATE ou DELETE sempre com WHERE.' },
      { quem: 'salsicha', humor: 'assustado', fala: 'Sem WHERE, eu apago o museu inteiro? Anotado!' }] },
  n2fim: { cenario: 'arquivo',
    falas: [
      { quem: 'daphne', humor: 'feliz', fala: 'Sabemos o que sumiu, quanto vale e quem tem álibi.' },
      { quem: 'velma', humor: 'pensativo', fala: 'Falta cruzar os dados para achar o culpado.' }] },
  n3: { cenario: 'galeria', abertura: ['Episódio 3', 'A identidade do fantasma'],
    falas: [
      { quem: 'velma', fala: 'Hora de agrupar, somar, cruzar tabelas e montar o dossiê final.' },
      { quem: 'fred', humor: 'bravo', fala: 'Precisão agora. Uma consulta errada pode acusar a pessoa errada.' },
      { quem: 'scooby', fala: 'Au-au! (Tradução: ele quer o dossiê... e um biscoito.)' }] },
  n3fim: { cenario: 'galeria',
    falas: [
      { quem: 'velma', humor: 'surpreso', fala: 'O dossiê ficou pronto, e um nome se destaca dos demais.' },
      { quem: 'daphne', fala: 'Hora da revelação.' }] },
  final: { cenario: 'final', abertura: ['A revelação'],
    falas: [
      { quem: 'velma', humor: 'pensativo', fala: 'Pelo dossiê, {nome} reúne {n} pistas, muito mais que qualquer outro suspeito.' },
      { quem: 'fred', fala: 'Então vamos conferir quem está debaixo do lençol.' },
      { quem: 'vilao', humor: 'assustado', fala: 'Uuuuh... ninguém vai me desmascarar!' },
      { quem: 'silas', humor: 'bravo', efeito: 'flash', fala: 'Tudo bem, fui eu. Apaguei o banco para esconder o roubo dos arquivos.' },
      { quem: 'daphne', fala: 'A tinta azul nas luvas, na maçaneta e nas pegadas. Os dados não mentem.' },
      { quem: 'salsicha', humor: 'feliz', fala: 'E eu achando que o fantasma era a minha sombra!' },
      { quem: 'scooby', humor: 'feliz', fala: 'Au-au-au! (Tradução: caso encerrado, e agora é hora do lanche!)' },
      { quem: 'velma', humor: 'feliz', fala: 'Parabéns, detetive. Você resolveu o caso com lógica e um banco de dados de verdade.' }] }
};

/* Fala do personagem-guia ao abrir cada missão. */
const ABERTURAS = {
  1: 'O computador ainda liga! Pergunte ao catálogo do SGBD o que sobrou.',
  2: 'Cada amostra precisa de colunas com o tipo de dado certo.',
  3: 'Sem chave primária, o mesmo suspeito pode aparecer duas vezes.',
  4: 'Toda pista pertence a alguém. A chave estrangeira garante isso.',
  5: 'Mais uma tabela para reconstruir. Depois disso, o backup volta!',
  6: 'Backup restaurado! Quem tinha acesso ao museu na noite do crime?',
  7: 'Apelidos deixam o resultado mais legível sem mudar a tabela.',
  8: 'Tinta azul na Sala de Restauro. Que pistas estão por lá?',
  9: 'Combine condições: antigo, valioso e desaparecido.',
  10: 'Ordenar põe o que mais importa no topo da lista.',
  11: 'Rankings pedem poucas linhas. O LIMIT resolve.',
  12: 'Nova pista! Registre com INSERT, e a FOREIGN KEY confere o suspeito.',
  13: 'Um álibi mudou tudo. UPDATE com WHERE, só no suspeito certo.',
  14: 'Uma pista foi plantada. Remova só ela, com cuidado.',
  15: 'Agrupar mostra padrões que linhas soltas escondem.',
  16: 'Qual foi o prejuízo? Funções de agregação respondem em uma linha.',
  17: 'Sem repetições: qual foi o trajeto de Silas pelo museu?',
  18: 'Pistas e suspeitos vivem em tabelas diferentes. Una com JOIN.',
  19: 'O dossiê final: uma view que sempre mostra os dados atuais.'
};

/* Reações: respostas certas e erradas provocam personagens e expressões diferentes. */
const R = (quem, humor, fala) => ({ quem, humor, fala });
const REACOES = {
  ok: [R('fred', 'feliz', 'Execução limpa! É assim que se investiga.'), R('daphne', 'feliz', 'O banco respondeu exatamente como esperávamos!'),
    R('velma', 'feliz', 'Resultado conferido. Sua lógica estava certa.'), R('salsicha', 'surpreso', 'Funcionou de primeira? Eu nem sabia que era possível!'),
    R('scooby', 'feliz', 'Au-au! (Tradução do Salsicha: mandou bem!)')],
  erro: [R('salsicha', 'assustado', 'O SQL reclamou! Leia a mensagem com calma, ela aponta o problema.'), R('velma', 'pensativo', 'Erro de escrita ou nome errado? Confira com "Ver tabelas".'),
    R('fred', 'neutro', 'Sem pânico. Corrija e execute de novo.'), R('scooby', 'assustado', 'Rrrr? (Ele diz: tem um errinho escondido aí.)')],
  incompleto: [R('daphne', 'pensativo', 'Quase! O comando rodou, mas ainda não cumpre o objetivo.'), R('velma', 'pensativo', 'Releia o objetivo: cada detalhe do enunciado importa.'),
    R('fred', 'neutro', 'Compare o resultado com o que a missão pede.'), R('salsicha', 'surpreso', 'Rodou sem erro, mas o fantasma continua solto!')],
  bloqueio: [R('fred', 'bravo', 'Alto lá! Esse comando poderia destruir a investigação.'), R('daphne', 'bravo', 'Proteção ativada: sem WHERE ou em tabela protegida, não!'),
    R('velma', 'pensativo', 'Prudência: use condições para atingir só o que precisa.')],
  ajuda: [R('daphne', 'feliz', 'Tentar de novo faz parte. A dica pode ajudar, e vale a pena.'), R('velma', 'neutro', 'Divida o problema: o que a tabela guarda e o que a missão pede?'),
    R('scooby', 'feliz', 'Au! (Tradução: tente de novo, você consegue!)')],
  dica: [R('velma', 'pensativo', 'Uma dica! Use como guia, mas entenda cada parte.'), R('fred', 'neutro', 'Dicas custam pontos, mas aprender compensa.')],
  desfazer: [R('daphne', 'neutro', 'Missão desfeita. O banco voltou ao início desta missão.'), R('fred', 'neutro', 'Voltamos ao começo da missão. Dá para tentar de novo.')]
};
